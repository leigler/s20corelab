

// function example with two arguments (i.e. placeholders: number1 and number2)
function adding(number1, number2){
	console.log(number1 + number2)
}

adding(2,2)
adding(20000, -222)



function timeUnit(output, ourHtmlElement){	
	if(output < 10){
		ourHtmlElement.innerHTML = "0" + output;
	}else{
		ourHtmlElement.innerHTML = output;	
	}	
}


// repeater vars
var counter = 0;
var minuteCounter = 0;
var hourCounter = 0;

// get html elements
var seconds = document.getElementById("seconds")
var minutes = document.getElementById("minutes")
var hours = document.getElementById("hours")


/* timer: */
// myRepeater increases by 1 every second:
function myRepeater(){
	// console.log(counter)
	timeUnit(counter, seconds)
	counter = counter + 1;

	if(counter === 60){
		counter = 0;
		minuteCounter = minuteCounter + 1;
		
		if(minuteCounter === 60){
			minuteCounter = 0;
			hourCounter = hourCounter + 1;
			timeUnit(hourCounter, hours);	
		}

		timeUnit(minuteCounter, minutes);
	}
}

// run myRepeater as soon as the page loads:
myRepeater()

// run myRepeater every second with setInterval:
setInterval(myRepeater, 1000)



