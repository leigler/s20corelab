console.log("hello!");

// variables

var myString = "this is a string";

var myBoolean = true;
var myOtherBoolean = false;

var myFloat = 1.23456;
var myInteger = 5; // whole numbers

var myArray = ["apple", "orange", "pear"];
// list

var myObjects = {
	key : "a value",
	anArray : ["my", "array"],
	aNumber : 22
};

// console.log(myObjects.aNumber)

// getting elements from our HTML
var square = document.getElementById("square");
var circles = document.querySelectorAll(".circle");


// adding and removing classes
square.classList.add("circle")
square.classList.remove("circle")


// starting variables: (these are updated)
var red = 255;
var green = 0;
var blue = 0;
var towardsBlue = true;

setInterval(function(){

	// template literal:
	square.style.backgroundColor = `rgb(${red}, ${green}, ${blue})`;

	/*

		"pseudo code"

		i want to my square to go from red to blue and then back

		square: i'll make a div for that

		to go? i want it to change color every half second

		red to blue?

		how do i define red? blue? color? rgb...

		then back? how do i decide when somethings blue enough?

		if something is blue turn it back to red
			
			if(something = blue){
				
				towards red

			}

		if something is red turn it back to blue

	*/


	if(towardsBlue == true){
		blue = blue + 40;
		red = red - 40;
	}else{
		blue = blue - 40;
		red = red + 40;
	}
	
	// if we reach the maximums, switch direction
	if(blue >= 255 && red <= 0){
		towardsBlue = false;
	}else if(red >= 255 && blue <= 0){
		towardsBlue = true;
	}


	// square.style.backgroundColor = "rgb(" + red + ", " + green + ", " + blue + ")";

}, 500)


/* NEW SECTION */


// while loop
var j = 0;
while( j < 10 ){

	// do something
	// console.log(j);
	j = j + 1;
}


console.log("circles: ", circles.length)

// for loop
for (var i = 0; i < circles.length; i++) {

	circles[i].style.borderWidth = (i + 1)*2 + "px"; // strings
	circles[i].style.borderWidth = `${(i + 1)*2}px`; // template literals

}

// innerHTML adds content

var title = document.querySelector("h1");

// output content
console.log(title.innerHTML)

// redefined content
title.innerHTML = "Helloooooooooooo";

// add to the end of content
title.innerHTML = title.innerHTML + "  everyone!";
// shorthand is: title.innerHTML += "  everyone!";

// add to the beginning of content
title.innerHTML = "wait, " + title.innerHTML;


// insertAdjacentHTML adds new elements
var container = document.getElementById("container")

container.insertAdjacentHTML('beforeend', `
		<div class="circle"></div>
	`)

var degrees = 0;

setInterval(function(){

	for (var i = 0; i < 2; i++) {
		

		// Math.ceil means 1.00001 = 2
		// Math.floor means 1.9999999 = 1
		var r = Math.ceil(Math.random()*255); // 144.77989
		var g = Math.round(Math.random()*255);
		var b = Math.floor(Math.random()*255);

		container.insertAdjacentHTML('beforeend', `
			<div 
				class="circle"
				style="transform:skew(${degrees}deg);
						background-color: rgb(${r}, ${g}, ${b});"
			>hello!</div>
		`)

		degrees = degrees + 5;

	}

}, 1000)






setInterval(function(){

	var now = new Date();

	var clock = `${now.getHours()}: ${now.getMinutes()} : ${now.getSeconds()}`

	console.log(clock)

	// now.getHours()+ ":"  + now.getSeconds()

}, 1000)










